package days14;

public class Ex03__02 {

	public static void main(String[] args) {
		dispCar( new Car() );

	}

	private static void dispCar(Car car) {
		
		
	}

}
