package days14;

public class Ex09 {

	public static void main(String[] args) {
		// 시간정보 ( 시간, 분, 초 ) * 5개 저장
		/*
		 [ 1 ]
		int hour1, minute2, second3;
		int hour1, minute2, second3;
		int hour1, minute2, second3;
		int hour1, minute2, second3;
		*/
		
		// [ 2 ]
		/*
		int [] hourArr = new int[5];
		int [] minuteArr = new int[5];
		int [] secondArr = new int[5];
		*/
		
		// [ 3 ]
		
		// 클래스 선언 - time  -> 클래스 배열
		Time [] timeArr = new Time[5];
		
		
		
		
		
		
	}//main

}//class
