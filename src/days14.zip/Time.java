package days14;

public class Time {
	
	public 		int hour;
	protected 	int minute;
	int				second;
	private 	int milisecond;		// 1000ms = 1s 
	
	int nano;			// 1000000000 (9) 1s
	
	
	
}
