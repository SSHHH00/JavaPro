package days14;

/**
 * @author C_Seung_H0
 *				
 */
public class Ex11 {
	
	/*  [ 필드 ]
			ㄴ 1) 인스턴스 변수
		public String color;
			ㄴ 2) 클래스(static) 변수 
		public String int number;
		
	 */
	
	
	//매서드
	public static void main(String[] args) {	//지역변수
	/*
	[ 자바 변수의 선언되는 위치에 따른 종류 ]
							<선언 위치>		<생성시기>
	1. 인스턴스 변수			클래스 안			인스턴스가 생성될때		
 	2. 클래스(static)변수		클래스 안			클래스가 메모리에 올라갈때(프로그램실행시)
 	3. 지역변수 				{ 매서드 안, 		변수선언문 실행될때.
	 						초기화블럭, 
		 					생성자 안 }
		 
		 
		 */
		int age; // 지역변수
		String name; //지역변수		초기화X 오류
					 // 			
		
		
		
		
		
		
		
		
	}//main

}//class
